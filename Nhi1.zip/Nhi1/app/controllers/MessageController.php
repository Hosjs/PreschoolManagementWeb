<?php
/**
 * MessagesController - Quản lý tin nhắn
 */
class MessageController extends SecureController {
    
    function index($field_name = null, $field_value = null) {
        $db = $this->GetModel();
        $this->tablename = "messages"; // Tên bảng trong database

        $fields = ["id", "sender_id", "recipient_id", "subject", "message", "sent_at"];

        // Nếu có bộ lọc theo trường và giá trị (ví dụ: tìm kiếm tin nhắn theo người gửi)
        if ($field_name && $field_value) {
            $db->where($field_name, $field_value);
        }

        $messages = $db->get($this->tablename, null, $fields);
        
        // Trả về dữ liệu cho giao diện
        $this->view_data = $messages;
        $this->render_view("Message/list.php");
    }

    /**
     * Xem chi tiết tin nhắn theo ID
     */
    function view($id = null) {
        $db = $this->GetModel();

        if (!empty($id)) {
            $fields = ["id", "sender_id", "recipient_id", "subject", "message", "sent_at"];
            $db->where("id", $id);
            $record = $db->getOne($this->tablename, $fields);

            if ($record) {
                $this->view_data = $record;
                $this->render_view("Message/view.php");
            } else {
                $this->set_page_error("Không tìm thấy tin nhắn!");
                $this->render_view("Message/view.php");
            }
        } else {
            $this->set_page_error("ID tin nhắn không hợp lệ!");
            $this->render_view("Message/view.php");
        }
    }

    /**
     * Xóa tin nhắn theo ID
     */
    function delete($id = null) {
        $db = $this->GetModel();

        if (!empty($id)) {
            $db->where("id", $id);
            $delete = $db->delete($this->tablename);

            if ($delete) {
                set_flash_msg("Tin nhắn đã được xóa!", "success");
            } else {
                set_flash_msg("Lỗi khi xóa tin nhắn!", "danger");
            }
        } else {
            set_flash_msg("ID tin nhắn không hợp lệ!", "danger");
        }
        redirect_to("Message");
    }
}
