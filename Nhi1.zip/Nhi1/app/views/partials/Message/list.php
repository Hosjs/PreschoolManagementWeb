<section class="page">
    <div class="container">
        <h4 class="mb-3">Danh sách tin nhắn</h4>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Người gửi</th>
                    <th>Người nhận</th>
                    <th>Tiêu đề</th>
                    <th>Ngày gửi</th>
                    <th>Thao tác</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!isset($this->view_data) || empty($this->view_data)) {
                echo "<p class='text-danger'>Không có tin nhắn nào để hiển thị.</p>";
                }else{
                foreach ($this->view_data as $msg) { ?>
                <tr>
                    <td><?php echo $msg['sender_name']; ?></td>
                    <td><?php echo $msg['recipient_name']; ?></td>
                    <td><?php echo $msg['subject']; ?></td>
                    <td><?php echo date("d/m/Y H:i", strtotime($msg['sent_at'])); ?></td>
                    <td>
                        <a href="<?php print_link("messages/view/".$msg['id']); ?>" class="btn btn-info btn-sm">Xem</a>
                        <a href="<?php print_link("messages/delete/".$msg['id']); ?>" class="btn btn-danger btn-sm">Xóa</a>
                    </td>
                </tr>
                <?php }} ?>
            </tbody>
        </table>
    </div>
</section>
